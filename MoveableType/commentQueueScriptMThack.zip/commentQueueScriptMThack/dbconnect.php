<?
/*
	-----------------------------------------------
		Comment Queue (Moveable Type Hack)
		Written by Jennifer of scriptygoddess.com
		
		This script is available for download on
		scriptygoddess.com.

		Please do not re-distribute or remove
		this credit line.

		If you use this script, a link back to 
		scriptygoddess would be appreciated.
	-----------------------------------------------
*/

/*************
Server name - you will most likely not have to change this!
*************/
$dbserver = "localhost";

/*************
Name of your MT database
*************/
$db = "MTDATABASE";

/*************
mySQL username
*************/
$dbuser = "DB-USERNAME";

/*************
mySQL password
*************/
$dbpassword = "DB-PASSWORD";
?>
